using CloudMessaging.Models;
using CloudMessaging.Services;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;

var builder = WebApplication.CreateBuilder(args);

FirebaseApp.Create(new AppOptions()
{
    Credential = GoogleCredential.FromFile("private_key.json"),
});

// Add services to the container.
builder.Services.AddSingleton<IFirebaseCloudMessaging, FirebaseCloudMessaging>();

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseHttpsRedirection();

app.MapPost("/fcm/message", (CloudMessageRequest cloudMessage , IFirebaseCloudMessaging firebaseCloudMessaging ) =>
{
    firebaseCloudMessaging.SendMessage(cloudMessage.Title, cloudMessage.Body);
    return Results.Ok();
});

app.Run();
