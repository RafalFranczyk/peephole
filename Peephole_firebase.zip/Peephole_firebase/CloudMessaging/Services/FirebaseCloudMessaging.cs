﻿using FirebaseAdmin.Messaging;

namespace CloudMessaging.Services
{
    public class FirebaseCloudMessaging : IFirebaseCloudMessaging
    {
        public void SendMessage(string title, string body)
        {
            try
            {
                Message message = new()
                {
                    Notification = new Notification()
                    {
                        Title = title,
                        Body = body,
                    },
                    Android = new()
                    {
                        Notification = new()
                        {
                            Color = "#f45342",
                        },
                    },
                    Apns = new()
                    {
                        Aps = new()
                        {
                            ContentAvailable = true
                        }
                    },
                    Topic = "all",
                };
                string response = FirebaseMessaging.DefaultInstance.SendAsync(message).Result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
