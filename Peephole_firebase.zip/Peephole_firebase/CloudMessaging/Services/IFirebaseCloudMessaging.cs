﻿namespace CloudMessaging.Services
{
    public interface IFirebaseCloudMessaging
    {
        void SendMessage(string title, string body);
    }
}