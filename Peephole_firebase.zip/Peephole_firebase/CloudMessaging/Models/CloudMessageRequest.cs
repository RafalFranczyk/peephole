﻿using System.Text.Json.Serialization;

namespace CloudMessaging.Models
{
    public class CloudMessageRequest
    {
        [JsonPropertyName("title")]
        public string Title { get; set; }

        [JsonPropertyName("body")]
        public string Body { get; set; } 
    }
}
